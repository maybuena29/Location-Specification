const express = require('express');
const taxCtrl = require('../controllers/tax.controller');

const taxRoute = express.Router();

//Route for Tax Module
taxRoute.get('/api/tax/get', taxCtrl.display);
taxRoute.post('/api/tax/insert', taxCtrl.insert);
taxRoute.get('/api/tax/get/:id', taxCtrl.get);
taxRoute.put('/api/tax/update/:id', taxCtrl.update);
taxRoute.delete('/api/tax/remove/:id', taxCtrl.delete);
taxRoute.get('/api/tax/get/tx/active', taxCtrl.getTx);

module.exports = taxRoute;



